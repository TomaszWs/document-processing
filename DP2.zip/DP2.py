# Exercise 1:
# 1. Read the JSON data from 'data1.json'.
# 2. Extract and print all the sentences.

# Exercise 2:
# Sample NLP results
nlp_results = [
    {"text": "This is a sample sentence.", "tokens": ["This", "is", "a", "sample", "sentence", "."]},
    {"text": "Another sentence.", "tokens": ["Another", "sentence", "."]},
]
# 1. Create a JSON file to store the NLP results.
# 2. Write the NLP results to the JSON file in a structured format.

# Exercise 3:
# 1. Read the JSON data from 'books.json'.
# 2. Find all books by a Author A.
# 3. Find books published after 2019.
# 4. Calculate the average publication year of the books.

# Exercise 4:
# 1. Read the data from 'books.json' and 'authors.json'.
# 2. Combine the data to create a new JSON file that includes author names with book information.
